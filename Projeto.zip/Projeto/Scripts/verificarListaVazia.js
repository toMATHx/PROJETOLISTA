const mensagemListaVazia = document.querySelector(".mensagem-lista-vazia");

function verificarListaVazia(listaDeCompras) {
  const itens = listaDeCompras.querySelectorAll("li");
  if (mensagemListaVazia) {
    mensagemListaVazia.style.display = itens.length === 0 ? "block" : "none";
  }
}

export default verificarListaVazia;
