function gerarDiaDaSemana (){
    //Manipulando data e hora
    const diaDaSemana=new Date.now(toLocaldatestring)
}