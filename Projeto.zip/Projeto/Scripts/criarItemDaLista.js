
// Scripts/criarItemDaLista.js
import verificarListaVazia from "./verificarListaVazia.js";

export const inputItem = document.getElementById("input-item");
let contador = 0;

export function CriarItemDaLista() {
  const valor = inputItem.value.trim();
  if (valor === "") {
    alert("Por favor, insira um item!");
    return null;
  }

  const itemDaLista = document.createElement("li");

  const containerItemDaLista = document.createElement("div");
  containerItemDaLista.classList.add("lista-item-container");

  // Checkbox
  const inputCheckbox = document.createElement("input");
  inputCheckbox.type = "checkbox";
  inputCheckbox.id = "checkbox" + contador++;
  containerItemDaLista.appendChild(inputCheckbox);

  // Nome do item
  const nomeItem = document.createElement("p");
  nomeItem.textContent = valor;
  containerItemDaLista.appendChild(nomeItem);

  // Riscar/Desriscar ao clicar no checkbox
  inputCheckbox.addEventListener("click", function () {
    nomeItem.style.textDecoration = inputCheckbox.checked ? "line-through" : "none";
  });

  // Botão excluir
  const botaoExcluir = document.createElement("button");
  botaoExcluir.className = "item-lista-button botao-excluir";
  const iconeExcluir = document.createElement("i");
  iconeExcluir.className = "bi bi-trash-fill";
  botaoExcluir.appendChild(iconeExcluir);
  containerItemDaLista.appendChild(botaoExcluir);

  botaoExcluir.addEventListener("click", function () {
    if (confirm("Deseja realmente deletar esse item?")) {
      itemDaLista.remove();
      alert("Item deletado");
      const lista = document.getElementById("lista-de-compras");
      verificarListaVazia(lista);
    }
  });

  // Botão editar
  const botaoEditar = document.createElement("button");
  botaoEditar.className = "item-lista-button botao-editar";
  const iconeEditar = document.createElement("i");
  iconeEditar.className = "bi bi-pencil-fill";
  botaoEditar.appendChild(iconeEditar);
  containerItemDaLista.appendChild(botaoEditar);

  botaoEditar.addEventListener("click", function () {
    const novoNome = prompt("Digite o novo nome do item:", nomeItem.textContent);
    if (novoNome && novoNome.trim() !== "") {
      nomeItem.textContent = novoNome.trim();
    }
  });

  itemDaLista.appendChild(containerItemDaLista);
  return itemDaLista;
}
